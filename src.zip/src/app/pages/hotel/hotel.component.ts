import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.scss']
})
export class HotelComponent implements OnInit {
private
  constructor(private route:ActivatedRoute) {
    this.route.params.subscribe(params=>console.log(params))
   }

  ngOnInit() {
  
  }

}
