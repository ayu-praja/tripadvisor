import { FilterbycompanyPipe } from './filterbycompany.pipe';

describe('FilterbycompanyPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterbycompanyPipe();
    expect(pipe).toBeTruthy();
  });
});
