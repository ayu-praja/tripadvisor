import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-sidenav',
  templateUrl: './filter-sidenav.component.html',
  styleUrls: ['./filter-sidenav.component.scss']
})
export class FilterSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
